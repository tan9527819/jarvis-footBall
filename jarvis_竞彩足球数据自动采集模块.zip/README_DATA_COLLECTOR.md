# JARVIS Football Data Collector

自动采集公开足球历史数据，供“竞彩足球预测分析”使用。

## 当前
- football-data.co.uk 历史比赛结果
- 胜平负结果
- 主客队进球
- 部分公开欧赔字段
- 每次采集记录时间和来源

## 后续
API-Football 等需要密钥的数据源通过 GitHub Secrets 接入，不把 Key 写进网页或代码。

GitHub Actions 会每天自动运行，也可以手动运行。
