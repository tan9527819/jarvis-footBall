import csv, json, os, re
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = DATA / "matches" / "latest.json"
HISTORY = DATA / "history" / "collection_log.json"

# Public football-data.co.uk CSV source. The workflow can be extended with API-Football
# after its key is stored in GitHub Secrets; no key is placed in the repository.
SOURCES = [
    ("england_current", "https://www.football-data.co.uk/mmz4281/2627/E0.csv"),
    ("england_previous", "https://www.football-data.co.uk/mmz4281/2526/E0.csv"),
]

def fetch(url):
    req = Request(url, headers={"User-Agent": "Mozilla/5.0 JARVIS-Football-DataCollector/1.0"})
    with urlopen(req, timeout=30) as r:
        return r.read()

def parse_csv(raw):
    text = raw.decode("latin-1", errors="replace")
    rows = list(csv.DictReader(text.splitlines()))
    out = []
    for r in rows:
        out.append({
            "date": r.get("Date"),
            "home": r.get("HomeTeam"),
            "away": r.get("AwayTeam"),
            "home_goals": to_num(r.get("FTHG")),
            "away_goals": to_num(r.get("FTAG")),
            "result": r.get("FTR"),
            "home_odds": odds(r.get("B365H")),
            "draw_odds": odds(r.get("B365D")),
            "away_odds": odds(r.get("B365A")),
            "source": "football-data.co.uk",
        })
    return out

def to_num(v):
    try: return int(float(v))
    except: return None

def odds(v):
    try: return float(v)
    except: return None

def main():
    all_rows = []
    log = []
    for name, url in SOURCES:
        try:
            rows = parse_csv(fetch(url))
            all_rows.extend(rows)
            log.append({"source": name, "url": url, "rows": len(rows), "ok": True})
        except Exception as e:
            log.append({"source": name, "url": url, "rows": 0, "ok": False, "error": str(e)})

    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_count": len(log),
        "matches": all_rows,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    HISTORY.parent.mkdir(parents=True, exist_ok=True)
    HISTORY.write_text(json.dumps({"generated_at": payload["generated_at"], "sources": log},
                                  ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Collected {len(all_rows)} historical matches")

if __name__ == "__main__":
    main()
